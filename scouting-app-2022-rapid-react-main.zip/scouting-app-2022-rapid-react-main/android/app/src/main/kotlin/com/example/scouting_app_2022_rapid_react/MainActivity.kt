package com.example.scouting_app_2022_rapid_react

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
